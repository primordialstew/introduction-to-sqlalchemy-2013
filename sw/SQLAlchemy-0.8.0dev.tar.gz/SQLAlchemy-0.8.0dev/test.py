from sqlalchemy import *
from sqlalchemy.orm import *
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import event

Base = declarative_base()

Base = declarative_base()

class Task(Base):
    __tablename__ = 'tasks'
    id = Column(Integer, primary_key=True)
    hostID = Column(Integer, ForeignKey('hosts.id'))
    name = Column(String)
    host = relationship("Host", backref=backref("tasks", cascade_backrefs=False))

    def __init__(self, host, name):
        self.host = host
        self.name = name


class Host(Base):
    __tablename__ = 'hosts'
    id = Column(Integer, primary_key=True)
    hostname = Column(String)

s = Session()
myHost = Host(hostname="123")
s.add(myHost)

newTask1 = Task(myHost, "abc")

assert newTask1 not in s
