from sqlalchemy import *
from sqlalchemy.orm import *
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()

class A(Base):
    __tablename__ = "a"

    id = Column(Integer, primary_key=True)
    bs = relationship("B")


class B(Base):
    __tablename__ = "b"

    id = Column(Integer, primary_key=True)

    a_id = Column(Integer, ForeignKey('a.id'))

e = create_engine("sqlite://", echo=True)

Base.metadata.create_all(e)

s = Session(e)

s.add_all([
        A(bs=[B(), B(), B()])
])
s.commit()

a1 = s.query(A).first()
b1 = a1.bs[0]
b2 = a1.bs[1]

a1.bs.remove(b1)

s.commit()

A.bs.property.cascade = "all, delete-orphan"

a1.bs.remove(b2)

s.commit()