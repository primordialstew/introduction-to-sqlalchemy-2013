from sqlalchemy import *
from sqlalchemy.orm import *
from sqlalchemy.ext.declarative import declarative_base

Base = declarative_base()

user_course = Table('user_course', Base.metadata,
    Column('user_id', Integer, ForeignKey('users.id')),
    Column('course_id', Integer, ForeignKey('courses.id'))
)

user_event = Table('user_event', Base.metadata,
    Column('user_id', Integer, ForeignKey('users.id')),
    Column('event_id', Integer, ForeignKey('events.id'))
)

class User(Base):
    __tablename__ = 'users'
    id = Column(Integer, primary_key=True)

    courses = relationship("Course", secondary=user_course, backref="users")
    personal_events = relationship("Event", secondary=user_event, backref="users")

class Event(Base):
    __tablename__ = 'events'
    id = Column(Integer, primary_key=True)
    type = Column(String(45))

    __mapper_args__ = {
        'polymorphic_identity': 'event',
        'polymorphic_on': type
    }

class Course(Event):
    __tablename__ = 'courses'
    id = Column(Integer, ForeignKey('events.id'), primary_key=True)

    __mapper_args__ = {
        'polymorphic_identity': 'course',
    }

u1 = User()
c1 = Course()
u1.courses.append(c1)
