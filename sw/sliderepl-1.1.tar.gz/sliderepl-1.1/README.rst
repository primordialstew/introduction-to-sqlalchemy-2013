=========
sliderepl
=========

Run a python script as a series of "slides" for presentation.